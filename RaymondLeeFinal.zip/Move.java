/*
* Othello Project 
* ECE-469: Artifical Intelligence
* Move.java
*
* @author: Raymond Lee
*/

public class Move {
	boolean legal = false;
	int points;
	int y;
	int x;
}