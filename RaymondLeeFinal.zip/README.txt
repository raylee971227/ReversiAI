Raymond Lee
Reversi-AI
ECE-469: Artificial Intelligence
Prof. Carl Sable

Build the project:
	javac Othello.java

Run the game:
	java Othello

Pre-made board:
	see "input.txt" to see the format of input board.
